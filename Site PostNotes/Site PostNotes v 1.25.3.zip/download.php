<!DOCTYPE html>
<?php
include ("config.php");

@session_start();

if (!isset($_SESSION['login'])) {
    if($_SESSION['lang'] == "pt"){$_SESSION['mensagem'] = "Você precisa de uma conta para acessar esta página!";} else {$_SESSION['mensagem'] = "You need an account to access this page!";}
    echo "<script> Redirect('register.php') </script>";
    /*ob_start();
    header("Location: register.php");
    ob_end_flush();
    exit;
    */
}

function getArq() {
    $files = scandir("_files");
    foreach ($files as $key => $file)
    {
        if ($file == '..' || $file == '.')
        {
            unset($files[$key]);
            continue;
        }
        return $files;
    }
}
?>
<html lang="pt-br">
<head>
    <title> <?php echo ($_SESSION['lang'] == 'pt' ? 'Baixar || PostNotes' : 'Download || PostNotes') ?> </title>
    <meta charset="UTF-8"/>
    <link rel="stylesheet" type="text/css" href="_css/menu.css"/>
    <link rel="stylesheet" type="text/css" href="_css/footer.css" />
    <link rel="stylesheet" type="text/css" href="_css/indexstyle.css" />
    <script>
        function changebg(idimg){
            document.getElementById("fmenu").style.backgroundImage = "url(_images/notice"+ idimg.toString() +".png)";
        }
        function resize_corpo(size) {
            var delay=10;//1 seconds
            setTimeout(function(){
                document.getElementById("corpo").style.height = size;
            },delay);
        }
    </script>
</head>
<body>
<?php
include("menu.php");
?>

<header id="cabecalho">

</header>

<div id="min_size">
    <form action="baixar.php" method="post" name="download">
    <div id="tableRegister">
        <fieldset>
            <legend>Downloads:</legend>

            <a href="_files/postnotes.rar">BAIXAR (APENAS TESTE)</a>
            <?php
            /*
            $arquivos = getArq();
            $tam = sizeof($arquivos);

            for ($i=2;$i<$tam+2;$i++) {

                $ext = strtolower(strrchr($arquivos[$i],"."));
                $pre = explode("-",$arquivos[$i]);


                    ?>
                    <p><input type="submit" id="idDownload" name="nDownload" value="<?php echo $arquivos[$i]; ?>" /></p>
                <?php

            }
            */
            ?>
        </fieldset>
    </div>
    </form>
</div>

<?php require("footer.php"); ?>

</body>
</html>