<?php
@session_start();
$con = @mysql_connect('localhost','root','');
$db = @mysql_select_db('tcc');

include("function.php");

if(!$con || !$db) {
    echo mysql_error();
}

if (isset($_SESSION['mensagem'])) {
    echo "<script> alert('{$_SESSION['mensagem']}');</script>";
    unset ($_SESSION['mensagem']);
}

// Altera idioma
if(getUserLanguage() == "" || @$_SESSION['lang'] == ""){
	$_SESSION['lang']=getUserLanguage();
} else if (@$_REQUEST['idioma'] == "pt") {
	$_SESSION['lang']="pt";
	
} else if (@$_REQUEST['idioma'] != "") {
	$_SESSION['lang']="en";
}